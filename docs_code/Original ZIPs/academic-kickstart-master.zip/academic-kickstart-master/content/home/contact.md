+++
# Contact widget.
widget = "contact"
active = true
date = "2016-04-20T00:00:00"

title = "Contact"
subtitle = ""

# Order that this section will appear in.
weight = 70

# Automatically link email and phone?
autolink = true

+++

